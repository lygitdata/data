#' Generate summary statistics and distribution plot
#'
#' This function generates summary statistics and distribution plots for a given dataset.
#'
#' @param data The dataset for which the summary is to be generated.
#'
#' @return A list containing three main components:
#'   \itemize{
#'     \item \code{summary.stats}: Summary statistics for numeric variables.
#'     \item \code{numeric.dist.plot}: Histograms depicting the distribution of each numeric variable.
#'     \item \code{categorical.dist.plot}: Bar charts showing the distribution of each categorical variable.
#'   }
#'
#' @details
#' The function computes summary statistics for numeric variables including mean, median, quartiles, etc.
#' It also generates histograms for numeric variables and bar charts for categorical variables.
#'
#' @examples
#' \dontrun{
#' # Import example data
#' student.por = read.csv("https://data.ly.gd.edu.kg/student-por.csv")
#' # Convert categorical variables to factors
#' categorical.var = c("school", "sex", "address", "famsize", "Pstatus",
#'                     "Mjob", "Fjob", "reason", "guardian", "schoolsup",
#'                     "famsup", "paid", "activities", "nursery",
#'                     "higher", "internet", "romantic")
#' student.por[categorical.var] = lapply(student.por[categorical.var], as.factor)
#'
#' # Call the function
#' student.summary = data.summary(data = student.por)
#' # Get summary statistics table
#' student.summary$summary.stats
#' # Get histograms for numeric variables
#' for (histogram in student.summary$numeric.dist.plot) { print(histogram) }
#' # Get bar plots for categorical variables
#' for (barplot in student.summary$categorical.dist.plot) { print(barplot) }
#' }
#'
#' @import ggplot2
#' @importFrom knitr kable
#'
#' @export
data.summary = function(data) {
  # Set variable to store results
  results = list(summary.stats = list(),
                 numeric.dist.plot = list(),
                 categorical.dist.plot = list())

  # Get categorical variables
  categorical.variables = names(which(unlist(lapply(student.por[colnames(student.por)], is.factor))))

  # Get numeric variables
  numeric.variables = setdiff(colnames(data), categorical.variables)

  # Generate summary statistics for numeric variables
  summary.table = knitr::kable(t(do.call(cbind, lapply(data[numeric.variables], summary))),
                               caption = "Summary Statistics of Numeric Variables")
  results$summary.stats = summary.table

  # Create histograms for numeric variables
  for (i in 1:length(numeric.variables)) {
    histogram = ggplot2::ggplot(data, ggplot2::aes(x = !!as.name(numeric.variables[i]))) +
      ggplot2::geom_histogram(bins = 20) +
      ggplot2::geom_text(stat = 'count', ggplot2::aes(label = ggplot2::after_stat(count))) +
      ggplot2::labs(title = paste("Distribution of",
                                  numeric.variables[i],
                                  "(numeric variable)"))
    results$numeric.dist.plot[[numeric.variables[i]]] = histogram
  }

  # Create bar chart for categorical variables
  for (i in 1:length(categorical.variables)) {
    bar.plot = ggplot2::ggplot(data, ggplot2::aes(x = !!as.name(categorical.variables[i]))) +
      ggplot2::geom_bar() +
      ggplot2::geom_text(stat = 'count', ggplot2::aes(label = ggplot2::after_stat(count))) +
      ggplot2::labs(title = paste("Distribution of",
                                  categorical.variables[i],
                                  "(categorical variable)"))
    results$categorical.dist.plot[[categorical.variables[i]]] = bar.plot
  }

  return(results)
}
