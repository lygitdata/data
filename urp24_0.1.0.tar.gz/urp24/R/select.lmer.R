#' Select fixed effects for a `lmer` model
#'
#' This function aims to identify the most suitable combination of fixed effects for building a mixed-effects model via the `lmer` function.
#' It takes into account various fixed effect candidates provided in `fixed.effect.pool`, the specified random effects structure (`random.effect`), and the dataset (`data`).
#' Additionally, it can conduct cross-validation if enabled, evaluating the model's performance with metrics such as RMSE, MAE, and R2.
#'
#' @param response The response variable for the mixed-effects model.
#' @param fixed.effect.pool A vector containing the names of fixed effects to consider for selection.
#' @param random.effect A character string specifying the random effects structure for the model.
#' @param data The data frame containing the variables.
#' @param verbose Optional, default to \code{FALSE}.
#'               A logical value indicating whether to print detailed information about each model.
#' @param cv.param Optional, default to \code{list(enable = FALSE, n.fold = NULL, seed = NULL)}.
#'                A list of parameters controlling cross-validation, including \code{enable} (boolean), \code{n.fold} (integer), and \code{seed} (integer).
#'
#' @return A data frame containing information about each model, including the selected fixed effect set, AIC, BIC, and if cross-validation is enabled, additional metrics such as RMSE, MAE, and R2.
#'         Additionally, it provides rank values for each metric to aid in model comparison.
#'
#' @details
#' The function generates all possible combinations of fixed effects from the provided pool, constructs an `lmer` model for each combination, and computes evaluation metrics such as AIC and BIC.
#' Optionally, if cross-validation is enabled, it conducts cross-validation to evaluate the model's performance and computes additional metrics such as RMSE, MAE, and R2.
#' It then aggregates the results and ranks the models based on AIC, BIC, and cross-validation metrics.
#'
#' @examples
#' \dontrun{
#' # Import example data
#' student.por = read.csv("https://data.ly.gd.edu.kg/student-por.csv")
#' # Convert categorical variables to factors
#' categorical.var = c("school", "sex", "address", "famsize", "Pstatus",
#'                     "Mjob", "Fjob", "reason", "guardian", "schoolsup",
#'                     "famsup", "paid", "activities", "nursery",
#'                     "higher", "internet", "romantic")
#' student.por[categorical.var] = lapply(student.por[categorical.var], as.factor)
#'
#' selection = select.lmer(response = "G3",
#'                         fixed.effect.pool = c("Fjob", "Mjob", "G1", "G2"),
#'                         random.effect = "(1 | school)",
#'                         data = student.por,
#'                         verbose = TRUE,
#'                         cv.param = list(enable = TRUE,
#'                                         n.fold = 10,
#'                                         seed = 88))
#' selection
#' }
#'
#' @importFrom stats AIC BIC
#'
#' @export
select.lmer = function(response,
                       fixed.effect.pool,
                       random.effect,
                       data,
                       verbose = FALSE,
                       cv.param = list(enable = FALSE, n.fold = NULL, seed = NULL)) {
  # Check parameters for CV
  if (!is.list(cv.param)) {
    stop("Invalid class for cv.param. It must be a list.")
  }
  if (sum(names(cv.param) == c("enable", "n.fold", "seed")) < 3) {
    stop("Invalid parameters for cv.param. The arguments are 'enable' (boolean), 'n.fold' (integer), and 'seed' (integer).")
  }

  # Get all combinations of fixed effects
  all.fixed.effects = enumerate(fixed.effect.pool)

  # Create an empty data frame to store the result
  result = data.frame(matrix(ncol = length(fixed.effect.pool) + 4, nrow = 0))
  colnames(result) = c(fixed.effect.pool,
                       "AIC",
                       "BIC",
                       "AIC.Rank",
                       "BIC.Rank")
  if (cv.param$enable) {
    result = data.frame(matrix(ncol = length(fixed.effect.pool) + 10, nrow = 0))
    colnames(result) = c(fixed.effect.pool,
                         "AIC",
                         "BIC",
                         "RMSE",
                         "MAE",
                         "R2",
                         "AIC.Rank",
                         "BIC.Rank",
                         "RMSE.Rank",
                         "MAE.Rank",
                         "R2.Rank")
  }

  # Start selecting model
  for (i in 1:length(all.fixed.effects)) {
    # Build model and get summary and AIC
    model = build.lmer(response,
                       all.fixed.effects[[i]],
                       random.effect,
                       data)
    model.summary = summary(model)

    # Ger AIC and BIC
    model.AIC = stats::AIC(model)
    model.BIC = stats::BIC(model)

    # Do cross validation and get RMSE, MAE, and R2
    RMSE = NULL
    MAE = NULL
    R2 = NULL
    if (cv.param$enable) {
      cv = cv.lmer(response = response,
                   fixed.effect = all.fixed.effects[[i]],
                   random.effect = random.effect,
                   data = data,
                   n.fold = cv.param$n.fold,
                   seed = cv.param$seed)
      RMSE = cv$cv.result[1]
      MAE = cv$cv.result[2]
      R2 = cv$cv.result[3]
    }

    # Fill in data frame with result
    selected.fixed.effects.encoded = as.numeric(fixed.effect.pool %in% all.fixed.effects[[i]])
    if (cv.param$enable) {
      result[i, ] = c(selected.fixed.effects.encoded,
                      model.AIC,
                      model.BIC,
                      RMSE,
                      MAE,
                      R2,
                      NA,
                      NA,
                      NA,
                      NA,
                      NA)
    }
    else {
      result[i, ] = c(selected.fixed.effects.encoded,
                      model.AIC,
                      model.BIC,
                      NA,
                      NA)
    }


    # Print out the model summary if verbose
    if (verbose) {
      cat("======================================================\n")
      cat("  Model ", i, "\n")
      cat("------------------------------------------------------\n")
      print(model.summary)
      cat("======================================================\n\n\n\n\n\n")
    }
  }

  # Add rank for each metric
  result$AIC.Rank = rank(result$AIC, ties.method = "first")
  result$BIC.Rank = rank(result$BIC, ties.method = "first")
  if (cv.param$enable) {
    result$RMSE.Rank = rank(result$RMSE, ties.method = "first")
    result$MAE.Rank = rank(result$MAE, ties.method = "first")
    result$R2.Rank = length(result$R2) + 1 - rank(result$R2, ties.method = "first")
  }

  return(result)
}
