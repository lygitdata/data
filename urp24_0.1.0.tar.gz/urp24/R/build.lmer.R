#' Build lmer models
#'
#' This function constructs and fits a linear mixed-effects model using the provided parameters.
#'
#' @param response The dependent variable or response variable for the linear mixed-effects model.
#' @param fixed.effect A character vector specifying the fixed effects to be included in the model formula.
#' @param random.effect A character vector specifying the random effects to be included in the model formula.
#' @param data The dataframe containing the variables specified in the model formula.
#'
#' @return A fitted linear mixed-effects model object.
#'
#' @details
#' The function constructs a linear mixed-effects model formula based on the provided \code{response}, \code{fixed.effect}, and \code{random.effect} parameters.
#' It then fits the linear mixed-effects model using the constructed formula and the provided \code{data} dataframe.
#' The fitting is done using the \code{lmer} function from the \code{lme4} package.
#'
#' @examples
#' \dontrun{
#' # Import example data
#' student.por = read.csv("https://data.ly.gd.edu.kg/student-por.csv")
#' # Convert categorical variables to factors
#' categorical.var = c("school", "sex", "address", "famsize", "Pstatus",
#'                     "Mjob", "Fjob", "reason", "guardian", "schoolsup",
#'                     "famsup", "paid", "activities", "nursery",
#'                     "higher", "internet", "romantic")
#' student.por[categorical.var] = lapply(student.por[categorical.var], as.factor)
#'
#' lmer.model = build.lmer(response = "G3",
#'                         fixed.effect = c("age", "G1", "G2", "Fjob"),
#'                         random.effect = "(1 | school)",
#'                         data = student.por)
#' summary(lmer.model)
#' }
#'
#' @import lme4
#'
#' @export
build.lmer = function(response,
                      fixed.effect,
                      random.effect,
                      data) {
  # Check if all the passed-in fixed effects are valid
  unique.fixed.effects = unique(
    unlist(
      lapply(
        fixed.effect,
        function(term) {
          term = gsub("\\s*\\^\\d+", "", term)
          term = gsub("\\s*\\*\\s*", ",", term)
          variables = unlist(strsplit(term, ","))
          variables = trimws(variables)
          unique(variables)
        }
      )
    )
  )
  invalid.fixed.effects = setdiff(unique.fixed.effects, colnames(data))
  if (length(invalid.fixed.effects) > 0) {
    stop("Invalid column names: ", paste(invalid.fixed.effects, collapse = ", "))
  }

  # Check for missing values in fixed effects
  missing.fixed.effects = lapply(
    fixed.effect,
    function(term) {
      number.of.na = sum(is.na(data[[term]]))
      if (number.of.na > 0) {
        stop(paste("Missing values found in column ", term, ": ", number.of.na, sep = ""))
        return(list(column = term, count = number.of.na))
      }
    }
  )
  missing.fixed.effects = Filter(Negate(is.null), missing.fixed.effects)

  # Build lmer model
  lmer.model = lme4::lmer(as.formula(paste(response,
                                           "~",
                                           paste(fixed.effect, collapse = "+"),
                                           "+",
                                           random.effect)),
                          data)
  return(lmer.model)
}
