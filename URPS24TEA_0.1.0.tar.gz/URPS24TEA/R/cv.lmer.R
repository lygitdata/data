#' Perform cross-validation for a linear mixed-effects model (`lmer`)
#'
#' This function performs k-fold cross-validation for a linear mixed-effects model specified by the `lmer` function.
#'
#' @param response The response variable for the mixed-effects model.
#' @param fixed.effect A character vector containing the names of fixed effects to be included in the model formula.
#' @param random.effect A character string specifying the random effects structure for the model.
#' @param data The data frame containing the variables.
#' @param n.fold Optional, default to 10. The number of folds for cross-validation.
#' @param seed Optional, default to `NULL`. A seed for reproducibility.
#'
#' @return A list containing the following components:
#'   \itemize{
#'     \item \code{validation.index}: A list of indices indicating the data points in each fold.
#'     \item \code{cv.log}: A data frame containing the cross-validation results for each fold, including RMSE, MAE, and R2.
#'     \item \code{cv.result}: A vector containing the average RMSE, MAE, and R2 across all folds.
#'     \item \code{cv.plot}: A ggplot object representing the cross-validation plot.
#'   }
#'
#' @details
#' The function performs k-fold cross-validation for a linear mixed-effects model. It divides the data into k folds, fits a model for each fold, predicts the response variable for the validation set, and calculates evaluation metrics such as RMSE, MAE, and R2 for each fold. It then aggregates the results and generates a plot to visualize the cross-validation metrics for each fold.
#'
#' @examples
#' # Import example data
#' student.por = read.csv("https://data.ly.gd.edu.kg/student-por.csv")
#'
#' # Convert categorical variables to factors
#' categorical.var = c("school", "sex", "address", "famsize", "Pstatus",
#'                     "Mjob", "Fjob", "reason", "guardian", "schoolsup",
#'                     "famsup", "paid", "activities", "nursery",
#'                     "higher", "internet", "romantic")
#' student.por[categorical.var] = lapply(student.por[categorical.var], as.factor)
#'
#' # Call the function
#' cv = cv.lmer(response = "G3",
#'              fixed.effect = c("G1", "G2", "Mjob", "Fjob", "sex"),
#'              random.effect = "(1 | school)",
#'              data = student.por,
#'              n.fold = 10,
#'              seed = 88)
#'
#' # Get the cross validation validation set index
#' cv$validation.index
#'
#' # Get the cross validation log
#' cv$cv.log
#'
#' # Get the cross validation result
#' cv$cv.result
#'
#' # Get the cross validation plot
#' cv$cv.plot
#'
#' @importFrom ggplot2 aes geom_line geom_point geom_hline annotate labs scale_color_manual
#' @importFrom caret createFolds
#'
#' @export
cv.lmer = function(response,
                   fixed.effect,
                   random.effect,
                   data,
                   n.fold = 10,
                   seed = NULL) {
  # Determine a seed
  if (!is.null(seed)) {
    set.seed(seed)
  }

  # Check if we have enough levels in the random effect
  random.effect.var = gsub("\\(1 \\| (\\w+)\\)", "\\1", random.effect)
  if (sum(summary(data[[random.effect.var]]) < n.fold)) {
    stop(
      "The number of observations in each level of the random effect ",
      paste(summary(data[[random.effect.var]]), collaps = ", "),
      " are less than number of fold ",
      n.fold
    )
  }

  # Get all the categorical variable names passed in
  included.cat.var = intersect(c(fixed.effect, random.effect.var),
                               names(unlist(lapply(data, is.factor))[unlist(lapply(data, is.factor))]))
  data$combined.cat = apply(data[included.cat.var], 1, function(row)
    paste(row, collapse = ","))
  validation.index = caret::createFolds(factor(data$combined), n.fold, returnTrain = F)

  # Create a data frame to store the cross validation results
  cv.log = data.frame(matrix(nrow = 0, ncol = 5))
  colnames(cv.log) = c("Fold", "MSE", "MAE", "R2")

  # Start Cross Validation
  fold = 0
  for (test in validation.index) {
    # Validation & train sets split
    validation.set = data[test, ]
    train.set = data[-test, ]

    # Build mixed effect model
    model = build.lmer(response,
                       fixed.effect,
                       random.effect,
                       train.set)
    y.pred = predict(model, validation.set)

    # Metrics
    fold = fold + 1
    fold.metric = data.frame(
      Fold = as.numeric(fold),
      RMSE = sqrt(mean((
        validation.set[[response]] - y.pred
      ) ^ 2)),
      MAE = mean(abs(validation.set[[response]] - y.pred)),
      R2 = cor(validation.set[[response]], y.pred) ^
        2
    )
    cv.log = rbind(cv.log, fold.metric)
  }

  # The cross validation result
  cv.result = c(
    RMSE = mean(cv.log$RMSE),
    MAE = mean(cv.log$MAE),
    R2 = mean(cv.log$R2)
  )

  # Create a plot based on the cross validation log
  cv.plot = ggplot2::ggplot(cv.log, ggplot2::aes(x = as.numeric(Fold))) +
    ggplot2::geom_line(ggplot2::aes(y = RMSE, color = "RMSE", group = 1)) +
    ggplot2::geom_point(ggplot2::aes(y = RMSE, color = "RMSE")) +
    ggplot2::geom_line(ggplot2::aes(y = MAE, color = "MAE", group = 2)) +
    ggplot2::geom_point(ggplot2::aes(y = MAE, color = "MAE")) +
    ggplot2::geom_line(ggplot2::aes(y = R2, color = "R2", group = 3)) +
    ggplot2::geom_point(ggplot2::aes(y = R2, color = "R2")) +
    ggplot2::geom_hline(yintercept = cv.result["RMSE"],
                        linetype = "dashed",
                        color = "red") +
    ggplot2::geom_hline(yintercept = cv.result["MAE"],
                        linetype = "dashed",
                        color = "blue") +
    ggplot2::geom_hline(
      yintercept = cv.result["R2"],
      linetype = "dashed",
      color = "darkgreen"
    ) +
    ggplot2::annotate(
      "text",
      x = 2,
      y = cv.result["RMSE"] + 0.05,
      label = paste("Average RMSE =", round(cv.result["RMSE"], 3)),
      color = "red"
    ) +
    ggplot2::annotate(
      "text",
      x = 2,
      y = cv.result["MAE"] + 0.05,
      label = paste("Average MAE =", round(cv.result["MAE"], 3)),
      color = "blue"
    ) +
    ggplot2::annotate(
      "text",
      x = 2,
      y = cv.result["R2"] + 0.05,
      label = paste("Average R2 =", round(cv.result["R2"], 3)),
      color = "darkgreen"
    ) +
    ggplot2::labs(
      title = "Cross Validation Metrics",
      x = "Fold",
      y = "Value",
      color = "Metric"
    ) +
    ggplot2::scale_color_manual(values = c(
      "RMSE" = "red",
      "MAE" = "blue",
      "R2" = "darkgreen"
    ))

  return(
    list(
      validation.index = validation.index,
      cv.log = cv.log,
      cv.result = cv.result,
      cv.plot = cv.plot
    )
  )
}
