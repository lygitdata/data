#' Generate all possible combinations of a given vector
#'
#' This function enumerates all possible combinations of elements from a given vector.
#'
#' @param input A vector containing elements for which all possible combinations are to be enumerated.
#'
#' @return A list containing all possible combinations of elements from the input vector.
#'
#' @details
#' The function initializes an empty list to store the enumerated vectors. It then iterates over each possible size of combinations from 1 to the length of the input vector.
#' For each size, it generates combinations using the \code{RcppAlgos::comboGeneral} function. It loops through each row of combinations and appends it to the list.
#'
#' @examples
#' enumerate(c("age", "Medu", "Fedu"))
#'
#' @importFrom RcppAlgos comboGeneral
#'
#' @export
enumerate = function(input) {
  # Create a list to store the enumerated vectors
  enueration.result = list()

  # Start enumeration
  for (i in 1:length(input)) {
    combinations = RcppAlgos::comboGeneral(input, i)
    for (j in 1:nrow(combinations)) {
      enueration.result = c(enueration.result, list(combinations[j,]))
    }
  }

  return(enueration.result)
}
